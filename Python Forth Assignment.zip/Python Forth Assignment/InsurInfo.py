# Description: Program to determine 3 customer's insurance policy information at the One Stop Insurance Company
# Author: Nicholas 
# Date(s): Mar 19 - 21, 2024


# Define required libraries.
import datetime
import FormatValues as FV
import time
import sys


# Define program constants.
# Open the defaults file and read the values into variables
f = open('Defaults.dat', 'r')
NEXT_POLICY_NUMBER = int(f.readline())
BASIC_PREMIUM = float(f.readline())
DISCOUNT_FOR_ADDITIONAL_CARS = float(f.readline())
COST_OF_EXTRA_LIABILITY_COVERAGE = float(f.readline())
COST_OF_GLASS_COVERAGE = float(f.readline())
COST_FOR_LOANER_CAR_COVERAGE = float(f.readline())
HST_RATE = float(f.readline())
MONTHLY_PROCESSING_FEE = float(f.readline())
f.close()

CurDate = datetime.datetime.now()


# Define program functions.



# Main program starts here.
while True:
    
    # Gather user inputs.
    CustFirstName = input("Enter the customer's first name: ").title()
    CustLastName = input("Enter the customer's last name: ").title()
    StrAddress = input("Enter the customer's street address: ")
    City = input("Enter the customer's city name: ").title()
    ProvLst = ["NL", "NS", "NB", "PE", "PQ", "ON", "MB", "AB", "BC", "NT", "YT", "NV"]
    
    while True:
        Prov = input("Enter the customer's province (XX): ")
        if Prov not in ProvLst:
            print("Error - invalid province.")
        else:
            break
    PostalCode = input("Enter the customer's postal code (XXX XXX): ")
    PhoneNumber = input("Enter the customer's phone number ((999) 999-9999): ")
    NumOfCarsInsur = input("Enter the customer's number of cars being insured: ")
    NumOfCarsInsur = int(NumOfCarsInsur)
    
    OptionalExtraLibailtyAmount = input("Enter if the customer requires a libality amount (Y or N): ").upper()
    OptionalGlassCoverage = input("Enter if the customer wants a glass coverage (Y or N): ").upper()
    OptionalLoanerCar = input("Enter if the customer has a loaner car (Y or N): ").upper()
        
    while True:
        PaymentPeroidLst = ["Full", "Monthly", "Down Pay"]
        PaymentPeroid = input("Enter how the customer wants to pay (Full or Monthly or Down Pay): ")
        if PaymentPeroid not in PaymentPeroidLst:
            print("Error - invalid input")
        elif PaymentPeroid == "Down Pay":
            DownPay = input("Enter the customer's down payment amount: ")
            DownPay = int(DownPay)
            break
        else:
            break
    
    ClaimNum = input("Enter the customer's claim number (99999): ")
    ClaimDate = input("Enter the customer's claim date (YYYY-MM-DD): ")
    ClaimDateDsp = datetime.datetime.strptime(ClaimDate, "%Y-%m-%d")
    ClaimAmount = input("Enter the customer's claim amount: ")
    ClaimAmount = int(ClaimAmount)
    

    
    
  

    # Perform required calculations.
    if NumOfCarsInsur < 2:
        TotPrice = BASIC_PREMIUM
    elif NumOfCarsInsur >= 2:
        OriginalPrice = BASIC_PREMIUM
        Discount = BASIC_PREMIUM * DISCOUNT_FOR_ADDITIONAL_CARS
        CostofAddCars = BASIC_PREMIUM - Discount
        TotPrice = BASIC_PREMIUM + CostofAddCars
    
    if OptionalExtraLibailtyAmount == "Y":
        ExtraLibailtyAmount = COST_OF_EXTRA_LIABILITY_COVERAGE * NumOfCarsInsur
    elif OptionalExtraLibailtyAmount == "N":
        ExtraLibailtyAmount = 0
    
    if OptionalGlassCoverage == "Y":
        GlassCoverageAmount =  COST_OF_GLASS_COVERAGE * NumOfCarsInsur
    elif OptionalGlassCoverage == "N":
        GlassCoverageAmount = 0

    if OptionalLoanerCar == "Y":
        LoanerCarAmount =  COST_FOR_LOANER_CAR_COVERAGE * NumOfCarsInsur
    elif OptionalLoanerCar == "N":
        LoanerCarAmount = 0
    
    TotalExtraCosts = ExtraLibailtyAmount + GlassCoverageAmount + LoanerCarAmount

    TotInsurPremium = TotPrice + TotalExtraCosts

    HST = TotInsurPremium * HST_RATE

    TotCost = TotInsurPremium + HST

    if PaymentPeroid == "Full":
        MonthlyPayment = (TotCost / 8) + MONTHLY_PROCESSING_FEE
    elif PaymentPeroid == "Monthly":
        MonthlyPayment = (TotCost / 8) + MONTHLY_PROCESSING_FEE
    elif PaymentPeroid == "Down Pay":
        MonthlyPayment = (TotPrice - DownPay) + MONTHLY_PROCESSING_FEE
    
    InvDate = CurDate

    if ClaimDateDsp.month == 1: 
        NextPaymentDate = "February 1"
    elif ClaimDateDsp.month == 2: 
        NextPaymentDate = "March 1"
    elif ClaimDateDsp.month == 3: 
        NextPaymentDate = "April 1"
    elif ClaimDateDsp.month == 4: 
        NextPaymentDate = "May 1"
    elif ClaimDateDsp.month == 5: 
        NextPaymentDate = "June 1"
    elif ClaimDateDsp.month == 6: 
        NextPaymentDate = "July 1"
    elif ClaimDateDsp.month == 7: 
        NextPaymentDate = "August 1"
    elif ClaimDateDsp.month == 8: 
        NextPaymentDate = "September 1"
    elif ClaimDateDsp.month == 9: 
        NextPaymentDate = "October 1"
    elif ClaimDateDsp.month == 10: 
        NextPaymentDate = "November 1"
    elif ClaimDateDsp.month == 11: 
        NextPaymentDate = "December 1"
    elif ClaimDateDsp.month == 12: 
        NextPaymentDate = "January 1"


    
    

    # Display results
    print()
    print("Insurance Policy Information for this customer at the One Stop Insurance Company")
    print("--------------------------------------------------------------------------------")
    print(f"First name:                                                           {CustFirstName}")
    print(f"Last name:                                                            {CustLastName}")
    print(f"Street address:                                                    {StrAddress}")
    print(f"Province:                                                                     {Prov:2s}")
    print(f"Postal code:                                                             {PostalCode:7s}")
    print(f"Phone number:                                                     {PhoneNumber:14s}")
    print("--------------------------------------------------------------------------------")
    print(f"Number of cars being insured:                                               {NumOfCarsInsur}")
    print(f"Extra liability:                                                              {OptionalExtraLibailtyAmount:1s}")
    print(f"Glass coverage:                                                               {OptionalGlassCoverage:1s}")
    print(f"Loaner car:                                                                   {OptionalLoanerCar:1s}")
    print("--------------------------------------------------------------------------------")
    print(f"Payment peroid:                                                       {PaymentPeroid}")
    if PaymentPeroid == "Down Pay":
        print(f"Down payment amount:                                              {FV.FDollar1(DownPay):10s}")
    else:
        print()
    print("--------------------------------------------------------------------------------")
    print(f"Claim number:                                                              {ClaimNum:>5s}")
    print(f"Claim date:                                                           {ClaimDate:10s}")
    ClaimAmountDsp = "${:,.2f}".format(ClaimAmount)
    print(f"Claim amount:                                                         {FV.FDollar1(ClaimAmount):10s}")
    print("--------------------------------------------------------------------------------")
    print(f"Insurance premium amount:                                             {FV.FDollar2(TotPrice):9s}")
    print("--------------------------------------------------------------------------------")
    print(f"Extra libality amount:                                                {FV.FDollar1(ExtraLibailtyAmount):10s}")
    print(f"Glass coverage amount:                                                {FV.FDollar1(GlassCoverageAmount):10s}")
    print(f"Loaner car amount:                                                    {FV.FDollar1(LoanerCarAmount):10s}")
    print("--------------------------------------------------------------------------------")
    print(f"Total extra costs:                                                    {FV.FDollar1(TotalExtraCosts):10s}")
    print("--------------------------------------------------------------------------------")
    print(f"Total insurance premuim:                                              {FV.FDollar1(TotInsurPremium):10s}")
    print("--------------------------------------------------------------------------------")
    print(f"HST:                                                                  {FV.FDollar1(HST):10s}")
    print(f"Total cost:                                                           {FV.FDollar1(TotCost):10s}")
    print("--------------------------------------------------------------------------------")
    print(f"Monthly payment:                                                      {FV.FDollar1(MonthlyPayment):10s}")
    print("--------------------------------------------------------------------------------")
    print(f"Invoice date:                                                         {FV.FDateS(InvDate):10s}")
    print(f"First payment date:                                                  {NextPaymentDate}")
    


    
        
    


    # Write the values to a data file called InsurInfo.dat.
    for _ in range(5):  # Change to control no. of 'blinks'
        print('Saving customer insurance policy information ...', end='\r')
        time.sleep(.3)  # To create the blinking effect
        sys.stdout.write('\033[2K\r')  # Clears the entire line and carriage returns
        time.sleep(.3)

    
    f = open("InsurInfo.dat", "a")
 
    # All values written to file must be a string.  If you have a numeric
    # value, use the str() function to convert.
    f.write("{}, ".format(CustFirstName)) 
    f.write("{}, ".format(CustLastName))
    f.write("{}, ".format(StrAddress))
    f.write("{}, ".format(City))
    f.write("{}, ".format(Prov))
    f.write("{}, ".format(PostalCode))
    f.write("{}, ".format(PhoneNumber))
    f.write("{}, ".format(str(NumOfCarsInsur)))
    f.write("{}, ".format(OptionalExtraLibailtyAmount))
    f.write("{}, ".format(OptionalGlassCoverage))
    f.write("{}, ".format(OptionalLoanerCar))
    f.write("{}, ".format(PaymentPeroid))
    f.write("{}, ".format(ClaimNum))
    f.write("{}, ".format(ClaimDate))
    f.write("{}\n".format(ClaimAmountDsp))
    
    
    
    f.close()

    print()
    print("Customer insurance policy information successfully saved ...", end='\r')
    time.sleep(1)  # To create the blinking effect
    sys.stdout.write('\033[2K\r')  # Clears the entire line and carriage returns

    print()
    Cont = input("Do you want to process another customer's insurance policy information?(Y/N): ").upper()
    print()
    if Cont == "N":
    
    
        f = open("InsurInfo.dat", "r")
 
        # Process the each record in the data file.
        # The loop is saying "Process each record in the file."
        for CustomerRecord in f:
            # Read the current record. The .split() method reads the line
            # and breaks it into fields - placing it in a list.
            CustomerLst = CustomerRecord.split(",")
   
            # Grab the values needed from the list and assign to variables.
            ClaimN = CustomerLst[12].strip()
            ClaimD = CustomerLst[13].strip()
            ClaimAP1 = CustomerLst[14].strip()
            CLaimAP2 = CustomerLst[15].strip()
            
            # Process the record - calculations, displaying results, writing to a new file, ...
            # No calculations required for this report
 
            # Print the detail line.    
            print(f"Claim #  Claim Date        Amount")
            print(f"---------------------------------")
            print(f"{ClaimN:5s}    {ClaimD:10s}    {ClaimAP1:3s},{CLaimAP2:6s}")
            print()
            sys.exit()
         
        


# Any housekeeping duties at the end of the program.

